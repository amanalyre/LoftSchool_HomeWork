# Верстка GameMagaz - макет магазина компьютерных игр.

##### Установка пакетов
```sh
$ npm install
```

##### Запуск Gulp - watch
```sh
$ gulp
```

##### Сборка проекта
```sh
$ gulp build
```

В проекте используется:
 - [Normalize-css](https://necolas.github.io/normalize.css/)
 - [FontAwesome.io](http://fontawesome.io/)